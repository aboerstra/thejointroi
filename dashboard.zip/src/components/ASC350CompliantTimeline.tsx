import React from 'react';
import MethodologyDropdown from './MethodologyDropdown';

const ASC350CompliantTimeline: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
      <h2 className="text-xl font-bold mb-4">Implementation Timeline (ASC 350-40 Compliant)</h2>
      
      <div className="relative">
        <div className="absolute top-0 bottom-0 left-[15px] w-0.5 bg-gray-200"></div>
        
        <div className="relative z-10">
          <div className="flex mb-8">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#3A0A3A] text-white flex items-center justify-center mr-4">1</div>
            <div>
              <h3 className="text-lg font-semibold">Interface Specification & System Architecture</h3>
              <p className="text-gray-600 mb-2">2 months | $85,000</p>
              <p className="text-sm text-gray-600 mb-2">
                Technical design, interface specifications, system architecture, database design
              </p>
              <MethodologyDropdown title="ASC 350-40 Compliance">
                <p className="mb-2">
                  <strong>Capitalization Eligibility:</strong> This phase is fully capitalizable under ASC 350-40 as it involves technical design activities that directly contribute to the development of software for internal use.
                </p>
                <p>
                  <strong>Corporate vs. Franchise Impact:</strong> The entire implementation cost is borne by corporate, as the software is developed for use across the franchise system. This is reflected in the corporate ROI calculations, where the full implementation cost is allocated to corporate while benefits are split between corporate and franchisees based on the royalty structure.
                </p>
              </MethodologyDropdown>
            </div>
          </div>
          
          <div className="flex mb-8">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#3A0A3A] text-white flex items-center justify-center mr-4">2</div>
            <div>
              <h3 className="text-lg font-semibold">Development & Integration</h3>
              <p className="text-gray-600 mb-2">4 months | $150,000</p>
              <p className="text-sm text-gray-600 mb-2">
                Code development, API implementation, integration with existing systems
              </p>
              <MethodologyDropdown title="ASC 350-40 Compliance">
                <p className="mb-2">
                  <strong>Capitalization Eligibility:</strong> This phase is fully capitalizable under ASC 350-40 as it involves coding and development activities that directly contribute to the software's functionality.
                </p>
                <p>
                  <strong>Corporate vs. Franchise Impact:</strong> While corporate bears the full development cost, the microservices architecture will provide significant IT cost savings that accrue 100% to corporate, helping to offset this investment.
                </p>
              </MethodologyDropdown>
            </div>
          </div>
          
          <div className="flex mb-8">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#3A0A3A] text-white flex items-center justify-center mr-4">3</div>
            <div>
              <h3 className="text-lg font-semibold">Testing & Validation</h3>
              <p className="text-gray-600 mb-2">1.5 months | $55,000</p>
              <p className="text-sm text-gray-600 mb-2">
                Unit testing, integration testing, user acceptance testing
              </p>
              <MethodologyDropdown title="ASC 350-40 Compliance">
                <p className="mb-2">
                  <strong>Capitalization Eligibility:</strong> This phase is fully capitalizable under ASC 350-40 as it involves testing activities that are necessary to verify the software functions as intended.
                </p>
                <p>
                  <strong>Corporate vs. Franchise Impact:</strong> Testing ensures the system will deliver the expected benefits to both corporate and franchisees, with franchisees benefiting from operational efficiencies and corporate benefiting from both royalties on increased franchise revenue and direct IT cost savings.
                </p>
              </MethodologyDropdown>
            </div>
          </div>
          
          <div className="flex">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#3A0A3A] text-white flex items-center justify-center mr-4">4</div>
            <div>
              <h3 className="text-lg font-semibold">Deployment & Training</h3>
              <p className="text-gray-600 mb-2">1.5 months | $35,000</p>
              <p className="text-sm text-gray-600 mb-2">
                System deployment, staff training, go-live support
              </p>
              <MethodologyDropdown title="ASC 350-40 Compliance">
                <p className="mb-2">
                  <strong>Capitalization Eligibility:</strong> This phase is fully capitalizable under ASC 350-40 as it involves activities necessary to prepare the software for its intended use.
                </p>
                <p>
                  <strong>Corporate vs. Franchise Impact:</strong> Effective deployment and training are critical to realizing the full benefits across the franchise system. Corporate investment in comprehensive training will maximize the ROI for both corporate and franchisees.
                </p>
              </MethodologyDropdown>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-8 bg-gray-50 p-4 rounded-lg border-l-4 border-[#3A0A3A]">
        <h3 className="font-semibold mb-2">ASC 350-40 Compliance Notes</h3>
        <p className="text-sm text-gray-600 mb-2">
          This implementation plan follows ASC 350-40 guidelines for software capitalization. The project begins with Interface Specification & System Architecture, focusing on technical design activities that qualify for capitalization. No planning or exploration activities are included in the capitalized costs.
        </p>
        <p className="text-sm text-gray-600">
          <strong>Corporate vs. Franchise Financial Structure:</strong> The implementation cost of ${325000} is entirely borne by corporate, while benefits accrue to both corporate and franchisees. Corporate benefits include {7.1}% royalties on franchise revenue increases, plus 100% of IT cost savings. This financial structure is reflected in the ROI calculations, with separate views for corporate-only and system-wide benefits.
        </p>
      </div>
    </div>
  );
};

export default ASC350CompliantTimeline;

import React from 'react';
import { 
  formatCurrency 
} from '../lib/data';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface TimeImpactVisualizationProps {
  refreshTimeSavings: number;
  workaroundTimeSavings: number;
  extraStepsTimeSavings: number;
}

const TimeImpactVisualization: React.FC<TimeImpactVisualizationProps> = ({ 
  refreshTimeSavings,
  workaroundTimeSavings,
  extraStepsTimeSavings
}) => {
  // Assuming 2 staff per clinic for calculations
  const staffPerClinic = 2;
  
  const chartData = [
    {
      name: 'Per Staff Member',
      refreshing: refreshTimeSavings,
      workarounds: workaroundTimeSavings,
      extraSteps: extraStepsTimeSavings / staffPerClinic,
      total: refreshTimeSavings + workaroundTimeSavings + (extraStepsTimeSavings / staffPerClinic)
    },
    {
      name: 'Per Clinic',
      refreshing: refreshTimeSavings * staffPerClinic,
      workarounds: workaroundTimeSavings * staffPerClinic,
      extraSteps: extraStepsTimeSavings,
      total: (refreshTimeSavings + workaroundTimeSavings) * staffPerClinic + extraStepsTimeSavings
    },
    {
      name: 'Organization-wide (Daily)',
      refreshing: refreshTimeSavings * staffPerClinic * 950, // Using default clinic count
      workarounds: workaroundTimeSavings * staffPerClinic * 950,
      extraSteps: extraStepsTimeSavings * 950,
      total: ((refreshTimeSavings + workaroundTimeSavings) * staffPerClinic + extraStepsTimeSavings) * 950
    }
  ];
  
  // Convert minutes to hours for the organization-wide data
  chartData[2].refreshing /= 60;
  chartData[2].workarounds /= 60;
  chartData[2].extraSteps /= 60;
  chartData[2].total /= 60;
  
  const formatMinutes = (minutes: number) => {
    if (minutes >= 60) {
      return `${(minutes / 60).toFixed(1)} hours`;
    }
    return `${minutes.toFixed(1)} min`;
  };
  
  const formatTooltip = (value: number, name: string, props: any) => {
    if (props.dataKey === 'total') {
      return [`${formatMinutes(value)}`, 'Total Time Saved'];
    }
    
    const keyMap: {[key: string]: string} = {
      refreshing: 'System Refreshing',
      workarounds: 'Workarounds',
      extraSteps: 'Extra Steps'
    };
    
    return [`${formatMinutes(value)}`, keyMap[name] || name];
  };
  
  // Calculate financial impact
  const totalDailyTimeSavings = chartData[1].total; // minutes per day per clinic
  const totalAnnualHoursSaved = (totalDailyTimeSavings * 260 * 950) / 60; // 260 working days, 950 clinics, convert to hours
  const organizationWideSavings = totalAnnualHoursSaved * 30; // $30 average hourly wage
  
  // Calculate productivity gain as percentage of 8-hour workday
  const productivityGain = (totalDailyTimeSavings / (8 * 60)) * 100;
  
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
      <h2 className="text-xl font-bold mb-4">Time Impact Analysis</h2>
      
      <div className="mb-4">
        <p className="text-sm text-gray-600">
          Based on survey data showing Wellness Coordinators and staff spending significant time on system refreshing, 
          workarounds, and extra steps. The chart below shows time saved at different organizational levels.
        </p>
      </div>
      
      <ResponsiveContainer width="100%" height={400}>
        <BarChart
          data={chartData}
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis 
            label={{ 
              value: chartData[2].total > 100 ? 'Hours' : 'Minutes', 
              angle: -90, 
              position: 'insideLeft' 
            }} 
          />
          <Tooltip formatter={formatTooltip} />
          <Legend />
          <Bar dataKey="refreshing" name="System Refreshing" stackId="a" fill="#3b82f6" />
          <Bar dataKey="workarounds" name="Workarounds" stackId="a" fill="#10b981" />
          <Bar dataKey="extraSteps" name="Extra Steps" stackId="a" fill="#f59e0b" />
        </BarChart>
      </ResponsiveContainer>
      
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-blue-50 p-4 rounded-lg">
          <h3 className="font-semibold text-lg">Daily Time Savings</h3>
          <p className="text-3xl font-bold text-blue-600">
            {formatMinutes(totalDailyTimeSavings)}
          </p>
          <p className="text-sm text-gray-600 mt-1">Per clinic</p>
        </div>
        
        <div className="bg-green-50 p-4 rounded-lg">
          <h3 className="font-semibold text-lg">Annual Financial Impact</h3>
          <p className="text-3xl font-bold text-green-600">
            {formatCurrency(organizationWideSavings)}
          </p>
          <p className="text-sm text-gray-600 mt-1">Organization-wide</p>
        </div>
        
        <div className="bg-amber-50 p-4 rounded-lg">
          <h3 className="font-semibold text-lg">Productivity Gain</h3>
          <p className="text-3xl font-bold text-amber-600">
            {productivityGain.toFixed(1)}%
          </p>
          <p className="text-sm text-gray-600 mt-1">Of 8-hour workday</p>
        </div>
      </div>
    </div>
  );
};

export default TimeImpactVisualization;

import React from 'react';
import { BusinessCaseData } from '../lib/data';

interface ROISummaryProps {
  totalAnnualBenefits: number;
  corporateAnnualBenefits: number;
  franchiseAnnualBenefits: number;
  paybackPeriodMonths: number;
  corporatePaybackPeriodMonths: number;
  firstYearROI: number;
  corporateFirstYearROI: number;
  fiveYearROI: number;
  corporateFiveYearROI: number;
  clinicCount: number;
  implementationCost: number;
  showCorporateView: boolean;
  toggleView: () => void;
}

const ROISummary: React.FC<ROISummaryProps> = ({
  totalAnnualBenefits,
  corporateAnnualBenefits,
  franchiseAnnualBenefits,
  paybackPeriodMonths,
  corporatePaybackPeriodMonths,
  firstYearROI,
  corporateFirstYearROI,
  fiveYearROI,
  corporateFiveYearROI,
  clinicCount,
  implementationCost,
  showCorporateView
}) => {
  const annualBenefits = showCorporateView ? corporateAnnualBenefits : totalAnnualBenefits;
  const paybackPeriod = showCorporateView ? corporatePaybackPeriodMonths : paybackPeriodMonths;
  const firstYearROIValue = showCorporateView ? corporateFirstYearROI : firstYearROI;
  const fiveYearROIValue = showCorporateView ? corporateFiveYearROI : fiveYearROI;
  
  return (
    <div className="bg-[#38003C] text-white rounded-lg shadow-lg p-6 mb-6">
      <div className="flex items-center mb-4">
        <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M5 3a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2V5a2 2 0 00-2-2H5zm9 4a1 1 0 10-2 0v6a1 1 0 102 0V7zm-3 2a1 1 0 10-2 0v4a1 1 0 102 0V9zm-3 3a1 1 0 10-2 0v1a1 1 0 102 0v-1z" clipRule="evenodd" />
        </svg>
        <h2 className="text-xl font-bold">ROI Summary</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#38003C]/80 p-4 rounded">
          <h3 className="text-sm font-medium mb-1">Annual Benefits:</h3>
          <p className="text-2xl font-bold">${annualBenefits.toLocaleString()}</p>
          <p className="text-xs mt-1">
            {showCorporateView && `($${franchiseAnnualBenefits.toLocaleString()} to franchisees)`}
          </p>
        </div>
        
        <div className="bg-[#38003C]/80 p-4 rounded">
          <h3 className="text-sm font-medium mb-1">Payback Period:</h3>
          <p className="text-2xl font-bold">{paybackPeriod.toFixed(1)} months</p>
          <p className="text-xs mt-1">{clinicCount} clinics</p>
        </div>
        
        <div className="bg-[#38003C]/80 p-4 rounded">
          <h3 className="text-sm font-medium mb-1">First Year ROI:</h3>
          <p className="text-2xl font-bold">{firstYearROIValue.toFixed(0)}%</p>
          <p className="text-xs mt-1">${implementationCost.toLocaleString()} investment</p>
        </div>
        
        <div className="bg-[#38003C]/80 p-4 rounded">
          <h3 className="text-sm font-medium mb-1">5-Year ROI:</h3>
          <p className="text-2xl font-bold">{fiveYearROIValue.toFixed(0)}%</p>
          <p className="text-xs mt-1">${(annualBenefits * 5).toLocaleString()} total return</p>
        </div>
      </div>
      
      <p className="mt-4 text-sm">
        {showCorporateView 
          ? "Corporate view shows only benefits that accrue to The Joint corporate entity, with implementation costs paid by corporate."
          : "Based on " + clinicCount + " clinics with an implementation cost of $" + implementationCost.toLocaleString()}
      </p>
    </div>
  );
};

export default ROISummary;

import React from 'react';
import { BusinessCaseData, BenefitCalculation, formatCurrency } from '../lib/data';
import html2pdf from 'html2pdf.js';

interface PDFExportProps {
  data: BusinessCaseData;
  benefits: BenefitCalculation;
  showCorporateView: boolean;
}

const PDFExport: React.FC<PDFExportProps> = ({ data, benefits, showCorporateView }) => {
  const handleExport = () => {
    const element = document.createElement('div');
    element.innerHTML = generatePDFContent();
    element.style.width = '8.5in';
    element.style.padding = '0.5in';
    
    const opt = {
      margin: [0.5, 0.5, 0.5, 0.5],
      filename: `The_Joint_Front_Office_Business_Case_${showCorporateView ? 'Corporate' : 'System'}_View.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    
    html2pdf().set(opt).from(element).save();
  };
  
  const generatePDFContent = () => {
    return `
      <style>
        body {
          font-family: Arial, sans-serif;
          color: #333;
          line-height: 1.5;
        }
        .header {
          background-color: #3A0A3A;
          color: white;
          padding: 20px;
          margin-bottom: 20px;
          text-align: center;
        }
        .section {
          margin-bottom: 30px;
        }
        .section-title {
          font-size: 18px;
          font-weight: bold;
          margin-bottom: 10px;
          color: #3A0A3A;
          border-bottom: 2px solid #1D7D63;
          padding-bottom: 5px;
        }
        .benefit-card {
          background-color: #f8f9fa;
          border-radius: 5px;
          padding: 15px;
          margin-bottom: 15px;
        }
        .benefit-title {
          font-weight: bold;
          margin-bottom: 5px;
        }
        .benefit-value {
          font-size: 18px;
          font-weight: bold;
          color: #1D7D63;
        }
        .benefit-description {
          font-size: 14px;
          color: #666;
        }
        .summary-box {
          background-color: #f0f0f0;
          border-left: 4px solid #3A0A3A;
          padding: 15px;
          margin-bottom: 20px;
        }
        .timeline {
          display: flex;
          margin-bottom: 20px;
        }
        .timeline-item {
          flex: 1;
          padding: 10px;
          background-color: #e9ecef;
          margin-right: 5px;
          font-size: 14px;
          text-align: center;
        }
        .timeline-item:last-child {
          margin-right: 0;
        }
        .footer {
          font-size: 12px;
          color: #666;
          text-align: center;
          margin-top: 30px;
          border-top: 1px solid #ddd;
          padding-top: 10px;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 20px;
        }
        th, td {
          border: 1px solid #ddd;
          padding: 8px;
          text-align: left;
        }
        th {
          background-color: #f2f2f2;
        }
      </style>
      
      <div class="header">
        <h1>The Joint Chiropractic</h1>
        <h2>Front Office System Modernization Business Case</h2>
        <p>${showCorporateView ? 'Corporate View' : 'System-Wide View'}</p>
      </div>
      
      <div class="section">
        <div class="section-title">ROI Summary</div>
        <div class="summary-box">
          <p><strong>Implementation Cost:</strong> ${formatCurrency(data.implementationCost)}</p>
          <p><strong>Annual Benefits:</strong> ${formatCurrency(showCorporateView ? benefits.corporateAnnualBenefits : benefits.totalAnnualBenefits)}</p>
          <p><strong>Payback Period:</strong> ${(showCorporateView ? benefits.corporatePaybackPeriodMonths : benefits.paybackPeriodMonths).toFixed(1)} months</p>
          <p><strong>First Year ROI:</strong> ${(showCorporateView ? benefits.corporateFirstYearROI : benefits.firstYearROI).toFixed(0)}%</p>
          <p><strong>5-Year ROI:</strong> ${(showCorporateView ? benefits.corporateFiveYearROI : benefits.fiveYearROI).toFixed(0)}%</p>
          <p><strong>5-Year Cumulative Return:</strong> ${formatCurrency(benefits.fiveYearCumulativeBenefits)}</p>
        </div>
      </div>
      
      <div class="section">
        <div class="section-title">Executive Summary</div>
        <p>
          The Joint Chiropractic's Front Office system modernization project presents a compelling business case with significant benefits for both corporate and franchise operations. Based on survey data from 411 staff members across the system, we've identified critical pain points that can be addressed through targeted improvements.
        </p>
        <p>
          <strong>Key findings:</strong> Staff currently spend significant time on system refreshes (76.3% report this issue), workarounds (68.4%), and unnecessary steps (62.8%). Additionally, 53.4% report payment processing failures resulting in revenue leakage.
        </p>
        <p>
          <strong>Proposed solution:</strong> Implement a modernized Front Office system with microservices architecture to eliminate these inefficiencies, reduce revenue leakage, improve retention, and decrease IT costs.
        </p>
        <p>
          <strong>Financial impact:</strong> The project requires a ${showCorporateView ? "corporate investment" : "one-time investment"} of ${data.implementationCost.toLocaleString()} with an estimated annual benefit of ${showCorporateView ? benefits.corporateAnnualBenefits.toLocaleString() + " to corporate" : benefits.totalAnnualBenefits.toLocaleString() + " system-wide"}, resulting in a payback period of ${showCorporateView ? benefits.corporatePaybackPeriodMonths.toFixed(1) : benefits.paybackPeriodMonths.toFixed(1)} months and a 5-year ROI of ${showCorporateView ? benefits.corporateFiveYearROI.toFixed(0) : benefits.fiveYearROI.toFixed(0)}%.
        </p>
        <p>
          <strong>Corporate vs. Franchise benefits:</strong> While the implementation cost is borne by corporate, benefits accrue to both corporate (through royalties, marketing fund contributions, and IT cost savings) and franchisees (through operational efficiencies and increased revenue). ${showCorporateView ? "This view shows only the benefits that accrue to corporate." : "This view shows the total system-wide benefits."}
        </p>
      </div>
      
      <div class="section">
        <div class="section-title">Benefits Breakdown</div>
        
        <div class="benefit-card">
          <div class="benefit-title">Time Savings</div>
          <div class="benefit-value">${formatCurrency(benefits.timeSavings)}</div>
          <div class="benefit-description">
            Reduced system refreshing, fewer workarounds, and streamlined patient processing
            ${showCorporateView ? `<br>Corporate receives ${formatCurrency(benefits.corporateTimeSavingsValue)} through royalties on franchise revenue increases` : ''}
          </div>
        </div>
        
        <div class="benefit-card">
          <div class="benefit-title">Error Reduction</div>
          <div class="benefit-value">${formatCurrency(benefits.errorReduction)}</div>
          <div class="benefit-description">
            Decreased payment processing errors and reduced revenue leakage
            ${showCorporateView ? `<br>Corporate receives ${formatCurrency(benefits.corporateRevenueLeakageRecovery)} through royalties on recovered revenue` : ''}
          </div>
        </div>
        
        <div class="benefit-card">
          <div class="benefit-title">Patient Retention</div>
          <div class="benefit-value">${formatCurrency(benefits.patientRetention)}</div>
          <div class="benefit-description">
            Improved membership management leading to better wellness plan retention
            ${showCorporateView ? `<br>Corporate receives ${formatCurrency(benefits.corporateRetentionImprovementValue)} through royalties on increased retention revenue` : ''}
          </div>
        </div>
        
        <div class="benefit-card">
          <div class="benefit-title">Microservices Benefits</div>
          <div class="benefit-value">${formatCurrency(benefits.microservicesBenefits)}</div>
          <div class="benefit-description">
            IT cost reduction, decreased downtime, and improved system resilience
            ${showCorporateView ? '<br>100% of IT cost savings accrue to corporate' : ''}
          </div>
        </div>
      </div>
      
      <div class="section">
        <div class="section-title">Implementation Timeline (ASC 350-40 Compliant)</div>
        <div class="timeline">
          <div class="timeline-item">Interface Specification & System Architecture</div>
          <div class="timeline-item">Development & Integration</div>
          <div class="timeline-item">Testing & Validation</div>
          <div class="timeline-item">Deployment & Training</div>
        </div>
        <p>
          This implementation plan follows ASC 350-40 guidelines for software capitalization. The project begins with Interface Specification & System Architecture, focusing on technical design activities that qualify for capitalization. No planning or exploration activities are included in the capitalized costs.
        </p>
      </div>
      
      <div class="section">
        <div class="section-title">Research-Based Guidance</div>
        <table>
          <tr>
            <th>Finding</th>
            <th>Source</th>
            <th>Recommendation</th>
          </tr>
          <tr>
            <td>76.3% of staff report refreshing the system "constantly" or "frequently"</td>
            <td>Survey Q34</td>
            <td>${data.refreshReductionPercent >= 70 ? 'Optimal' : data.refreshReductionPercent >= 50 ? 'Good' : 'Consider increasing'} (${data.refreshReductionPercent}%)</td>
          </tr>
          <tr>
            <td>68.4% describe having "a lot of inefficiencies, but I've learned workarounds"</td>
            <td>Survey Q6</td>
            <td>${data.workaroundReductionPercent >= 65 ? 'Optimal' : data.workaroundReductionPercent >= 45 ? 'Good' : 'Consider increasing'} (${data.workaroundReductionPercent}%)</td>
          </tr>
          <tr>
            <td>62.8% selected "Too many steps & dropdowns" for checkout</td>
            <td>Survey Q19</td>
            <td>${data.extraStepsReductionPercent >= 60 ? 'Optimal' : data.extraStepsReductionPercent >= 40 ? 'Good' : 'Consider increasing'} (${data.extraStepsReductionPercent}%)</td>
          </tr>
          <tr>
            <td>53.4% reported payment processing failures in the past week</td>
            <td>Survey Q32</td>
            <td>${data.revenueLeakageReductionPercent >= 50 ? 'Optimal' : data.revenueLeakageReductionPercent >= 30 ? 'Good' : 'Consider increasing'} (${data.revenueLeakageReductionPercent}%)</td>
          </tr>
          <tr>
            <td>Organizations implementing microservices architecture have reported up to a 30% reduction in IT costs</td>
            <td>McKinsey & Company</td>
            <td>${data.itCostReductionPercent >= 25 ? 'Optimal' : data.itCostReductionPercent >= 15 ? 'Good' : 'Consider increasing'} (${data.itCostReductionPercent}%)</td>
          </tr>
        </table>
      </div>
      
      <div class="footer">
        <p>Generated on ${new Date().toLocaleDateString()} | Prepared by Faye | WE EAT SOFTWARE</p>
      </div>
    `;
  };
  
  return (
    <button
      onClick={handleExport}
      className="bg-[#3A0A3A] hover:bg-[#4B1B4B] text-white font-bold py-2 px-4 rounded flex items-center"
    >
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V7.414A2 2 0 0015.414 6L12 2.586A2 2 0 0010.586 2H6zm5 6a1 1 0 10-2 0v3.586l-1.293-1.293a1 1 0 10-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 11.586V8z" clipRule="evenodd" />
      </svg>
      Export to PDF ({showCorporateView ? 'Corporate View' : 'System-Wide View'})
    </button>
  );
};

export default PDFExport;

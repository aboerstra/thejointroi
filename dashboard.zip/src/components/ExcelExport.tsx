import React from 'react';
import { BusinessCaseData, BenefitCalculation, formatCurrency } from '../lib/data';
import * as XLSX from 'xlsx';

interface ExcelExportProps {
  data: BusinessCaseData;
  benefits: BenefitCalculation;
  showCorporateView: boolean;
}

const ExcelExport: React.FC<ExcelExportProps> = ({ data, benefits, showCorporateView }) => {
  const handleExport = () => {
    // Create workbook
    const wb = XLSX.utils.book_new();
    
    // Add assumptions worksheet
    const assumptionsData = [
      ['The Joint Chiropractic - Front Office Business Case', null, null],
      [showCorporateView ? 'Corporate View' : 'System-Wide View', null, null],
      [null, null, null],
      ['Assumptions', null, null],
      ['Category', 'Parameter', 'Value'],
      ['Clinic Operations', 'Number of Clinics', data.clinicCount],
      ['Clinic Operations', 'Average Visits Per Day', data.averageVisitsPerDay],
      ['Clinic Operations', 'Average Hourly Wage ($)', data.averageHourlyWage],
      ['Clinic Operations', 'Average Clinic Revenue ($)', data.averageClinicRevenue],
      ['Time Savings', '% Reduction in System Refresh Time', data.refreshReductionPercent + '%'],
      ['Time Savings', '% Reduction in Workaround Time', data.workaroundReductionPercent + '%'],
      ['Time Savings', '% Reduction in Extra Steps Time', data.extraStepsReductionPercent + '%'],
      ['Error Reduction & Revenue', '% Recovery of Lost Revenue', data.revenueLeakageReductionPercent + '%'],
      ['Error Reduction & Revenue', 'Percentage Point Increase in Retention', data.retentionImprovementPercent + '%'],
      ['Microservices Benefits', '% Reduction in IT Costs', data.itCostReductionPercent + '%'],
      ['Microservices Benefits', '% Reduction in Downtime', data.downtimeReductionPercent + '%'],
      ['Implementation', 'Implementation Cost ($)', data.implementationCost],
      ['Corporate Benefit Allocation', 'Corporate Royalty Percentage', data.corporateRoyaltyPercent + '%'],
      ['Corporate Benefit Allocation', 'Corporate NMF Percentage', data.corporateNMFPercent + '%'],
      ['Corporate Benefit Allocation', 'Corporate IT Cost Allocation', data.corporateITCostAllocation + '%']
    ];
    
    const assumptionsWs = XLSX.utils.aoa_to_sheet(assumptionsData);
    XLSX.utils.book_append_sheet(wb, assumptionsWs, 'Assumptions');
    
    // Add calculations worksheet
    const calculationsData = [
      ['ROI Calculations', null, null, null],
      [null, 'System-Wide', 'Corporate', 'Franchise'],
      ['Annual Benefits', benefits.totalAnnualBenefits, benefits.corporateAnnualBenefits, benefits.franchiseAnnualBenefits],
      ['Payback Period (months)', benefits.paybackPeriodMonths, benefits.corporatePaybackPeriodMonths, null],
      ['First Year ROI (%)', benefits.firstYearROI, benefits.corporateFirstYearROI, null],
      ['Five Year ROI (%)', benefits.fiveYearROI, benefits.corporateFiveYearROI, null],
      ['Five-Year Cumulative Benefits', benefits.fiveYearCumulativeBenefits, benefits.corporateFiveYearCumulativeBenefits, null],
      [null, null, null, null],
      ['Benefit Breakdown', null, null, null],
      ['Category', 'System-Wide', 'Corporate', 'Franchise'],
      ['Time Savings', benefits.timeSavingsValue, benefits.corporateTimeSavingsValue, benefits.franchiseTimeSavingsValue],
      ['Revenue Leakage Recovery', benefits.revenueLeakageRecovery, benefits.corporateRevenueLeakageRecovery, benefits.franchiseRevenueLeakageRecovery],
      ['Retention Improvement', benefits.retentionImprovementValue, benefits.corporateRetentionImprovementValue, benefits.franchiseRetentionImprovementValue],
      ['IT Cost Reduction', benefits.itCostReduction, benefits.itCostReduction, 0],
      ['Total', benefits.totalAnnualBenefits, benefits.corporateAnnualBenefits, benefits.franchiseAnnualBenefits]
    ];
    
    const calculationsWs = XLSX.utils.aoa_to_sheet(calculationsData);
    XLSX.utils.book_append_sheet(wb, calculationsWs, 'Calculations');
    
    // Add research data worksheet
    const researchData = [
      ['Research Data', null, null],
      [null, null, null],
      ['Survey Findings', null, null],
      ['Finding', 'Source', 'Percentage'],
      ['Staff report refreshing the system "constantly" or "frequently"', 'Survey Q34', '76.3%'],
      ['Staff describe having "a lot of inefficiencies, but I\'ve learned workarounds"', 'Survey Q6', '68.4%'],
      ['Staff selected "Too many steps & dropdowns" for checkout', 'Survey Q19', '62.8%'],
      ['Staff reported payment processing failures in the past week', 'Survey Q32', '53.4%'],
      ['Staff describe patient search as "Takes Extra Steps"', 'Survey Q9', '52.6%'],
      ['Staff experienced double charges or incorrect charges', 'Survey Q20', '38.6%'],
      [null, null, null],
      ['Industry Research', null, null],
      ['Finding', 'Source', null],
      ['Organizations implementing microservices architecture have reported up to a 30% reduction in IT costs', 'McKinsey & Company', null],
      ['By 2025, 80% of digital businesses will adopt a composable architecture approach', 'Gartner', null],
      ['Healthcare organizations that modernize legacy systems through microservices architecture report 40% faster development cycles and 25-35% reduction in operational costs', 'Forrester', null],
      ['The global microservices architecture market is projected to reach $15.97 billion by 2029, growing at a CAGR of 21% from 2022 to 2029', 'Market Research', null]
    ];
    
    const researchWs = XLSX.utils.aoa_to_sheet(researchData);
    XLSX.utils.book_append_sheet(wb, researchWs, 'Research Data');
    
    // Add implementation timeline worksheet
    const timelineData = [
      ['Implementation Timeline (ASC 350-40 Compliant)', null, null, null],
      [null, null, null, null],
      ['Phase', 'Duration', 'Activities', 'Cost'],
      ['Interface Specification & System Architecture', '2 months', 'Technical design, interface specifications, system architecture, database design', '$85,000'],
      ['Development & Integration', '4 months', 'Code development, API implementation, integration with existing systems', '$150,000'],
      ['Testing & Validation', '1.5 months', 'Unit testing, integration testing, user acceptance testing', '$55,000'],
      ['Deployment & Training', '1.5 months', 'System deployment, staff training, go-live support', '$35,000'],
      [null, null, null, null],
      ['ASC 350-40 Compliance Notes', null, null, null],
      ['This implementation plan follows ASC 350-40 guidelines for software capitalization.', null, null, null],
      ['The project begins with Interface Specification & System Architecture, focusing on technical design activities that qualify for capitalization.', null, null, null],
      ['No planning or exploration activities are included in the capitalized costs.', null, null, null]
    ];
    
    const timelineWs = XLSX.utils.aoa_to_sheet(timelineData);
    XLSX.utils.book_append_sheet(wb, timelineWs, 'Implementation Timeline');
    
    // Generate Excel file
    XLSX.writeFile(wb, `The_Joint_Front_Office_Business_Case_${showCorporateView ? 'Corporate' : 'System'}_View.xlsx`);
  };
  
  return (
    <button
      onClick={handleExport}
      className="bg-[#1D7D63] hover:bg-[#2E8E74] text-white font-bold py-2 px-4 rounded flex items-center"
    >
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
      </svg>
      Export to Excel ({showCorporateView ? 'Corporate View' : 'System-Wide View'})
    </button>
  );
};

export default ExcelExport;

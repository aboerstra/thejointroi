import React, { useState, useEffect } from 'react';
import { BusinessCaseData, defaultBusinessCaseData } from '../lib/data';

interface ScenarioManagerProps {
  data: BusinessCaseData;
}

interface SavedScenario {
  name: string;
  description: string;
  data: BusinessCaseData;
  date: string;
}

const ScenarioManager: React.FC<ScenarioManagerProps> = ({ data }) => {
  const [scenarioName, setScenarioName] = useState<string>('');
  const [scenarioDescription, setScenarioDescription] = useState<string>('');
  const [savedScenarios, setSavedScenarios] = useState<SavedScenario[]>([]);
  const [showSaveDialog, setShowSaveDialog] = useState<boolean>(false);
  const [showLoadDialog, setShowLoadDialog] = useState<boolean>(false);
  
  // Load saved scenarios from localStorage on component mount
  useEffect(() => {
    const storedScenarios = localStorage.getItem('savedScenarios');
    if (storedScenarios) {
      setSavedScenarios(JSON.parse(storedScenarios));
    }
  }, []);
  
  const handleSaveScenario = () => {
    if (!scenarioName) return;
    
    const newScenario: SavedScenario = {
      name: scenarioName,
      description: scenarioDescription,
      data: data,
      date: new Date().toLocaleString()
    };
    
    const updatedScenarios = [...savedScenarios, newScenario];
    setSavedScenarios(updatedScenarios);
    localStorage.setItem('savedScenarios', JSON.stringify(updatedScenarios));
    
    setScenarioName('');
    setScenarioDescription('');
    setShowSaveDialog(false);
  };
  
  const handleLoadScenario = (scenario: SavedScenario) => {
    // Dispatch custom event to update data in parent components
    const event = new CustomEvent('scenario-loaded', { detail: { data: scenario.data } });
    window.dispatchEvent(event);
    setShowLoadDialog(false);
  };
  
  const handleDeleteScenario = (index: number) => {
    const updatedScenarios = savedScenarios.filter((_, i) => i !== index);
    setSavedScenarios(updatedScenarios);
    localStorage.setItem('savedScenarios', JSON.stringify(updatedScenarios));
  };
  
  const handleResetToDefault = () => {
    if (window.confirm('Are you sure you want to reset all values to default?')) {
      // Dispatch custom event to reset data in parent components
      const event = new CustomEvent('scenario-reset');
      window.dispatchEvent(event);
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Scenario Manager</h2>
        <div className="flex space-x-2">
          <button
            onClick={() => setShowSaveDialog(true)}
            className="bg-[#3A0A3A] hover:bg-[#4B1B4B] text-white px-3 py-1 rounded text-sm"
          >
            Save Scenario
          </button>
          <button
            onClick={() => setShowLoadDialog(true)}
            className="bg-[#1D7D63] hover:bg-[#2E8E74] text-white px-3 py-1 rounded text-sm"
            disabled={savedScenarios.length === 0}
          >
            Load Scenario
          </button>
          <button
            onClick={handleResetToDefault}
            className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-3 py-1 rounded text-sm"
          >
            Reset to Default
          </button>
        </div>
      </div>
      
      {/* Save Dialog */}
      {showSaveDialog && (
        <div className="bg-gray-100 p-4 rounded-lg mb-4">
          <h3 className="font-semibold mb-2">Save Current Scenario</h3>
          <div className="mb-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">Scenario Name</label>
            <input
              type="text"
              value={scenarioName}
              onChange={(e) => setScenarioName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[#3A0A3A] focus:border-[#3A0A3A]"
              placeholder="e.g., Conservative Estimate"
            />
          </div>
          <div className="mb-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">Description (Optional)</label>
            <textarea
              value={scenarioDescription}
              onChange={(e) => setScenarioDescription(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[#3A0A3A] focus:border-[#3A0A3A]"
              placeholder="e.g., Conservative estimates for presentation to CFO"
              rows={2}
            />
          </div>
          <div className="flex justify-end space-x-2">
            <button
              onClick={() => setShowSaveDialog(false)}
              className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-3 py-1 rounded text-sm"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveScenario}
              className="bg-[#3A0A3A] hover:bg-[#4B1B4B] text-white px-3 py-1 rounded text-sm"
              disabled={!scenarioName}
            >
              Save
            </button>
          </div>
        </div>
      )}
      
      {/* Load Dialog */}
      {showLoadDialog && (
        <div className="bg-gray-100 p-4 rounded-lg mb-4">
          <h3 className="font-semibold mb-2">Load Saved Scenario</h3>
          {savedScenarios.length === 0 ? (
            <p className="text-gray-600">No saved scenarios found.</p>
          ) : (
            <div className="max-h-60 overflow-y-auto">
              {savedScenarios.map((scenario, index) => (
                <div key={index} className="bg-white p-3 rounded-md mb-2 border border-gray-200">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">{scenario.name}</h4>
                      {scenario.description && (
                        <p className="text-sm text-gray-600 mt-1">{scenario.description}</p>
                      )}
                      <p className="text-xs text-gray-500 mt-1">Saved on {scenario.date}</p>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleLoadScenario(scenario)}
                        className="bg-[#1D7D63] hover:bg-[#2E8E74] text-white px-2 py-1 rounded text-xs"
                      >
                        Load
                      </button>
                      <button
                        onClick={() => handleDeleteScenario(index)}
                        className="bg-red-100 hover:bg-red-200 text-red-600 px-2 py-1 rounded text-xs"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          <div className="flex justify-end mt-3">
            <button
              onClick={() => setShowLoadDialog(false)}
              className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-3 py-1 rounded text-sm"
            >
              Close
            </button>
          </div>
        </div>
      )}
      
      <p className="text-sm text-gray-600">
        Use the scenario manager to save different sets of assumptions and easily switch between them for comparison.
      </p>
    </div>
  );
};

export default ScenarioManager;

import React from 'react';

interface BenefitsBreakdownProps {
  timeSavingsValue: number;
  revenueLeakageRecovery: number;
  retentionImprovementValue: number;
  itCostReduction: number;
  totalBenefits: number;
  showCorporateView: boolean;
}

const BenefitsBreakdown: React.FC<BenefitsBreakdownProps> = ({
  timeSavingsValue,
  revenueLeakageRecovery,
  retentionImprovementValue,
  itCostReduction,
  totalBenefits,
  showCorporateView
}) => {
  const formatCurrency = (value: number) => {
    return '$' + value.toLocaleString(undefined, { maximumFractionDigits: 0 });
  };
  
  const calculatePercentage = (value: number) => {
    return ((value / totalBenefits) * 100).toFixed(1) + '%';
  };
  
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
      <h2 className="text-xl font-bold mb-4 text-[#38003C]">Benefits Breakdown</h2>
      
      <div className="space-y-4">
        <div>
          <div className="flex justify-between items-center mb-1">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-[#38003C] mr-2"></div>
              <span className="font-medium">Time Savings</span>
            </div>
            <span className="font-medium">{formatCurrency(timeSavingsValue)}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-[#38003C] h-2.5 rounded-full" 
              style={{ width: calculatePercentage(timeSavingsValue) }}
            ></div>
          </div>
          <p className="text-sm text-gray-600 mt-1">
            {showCorporateView 
              ? "Corporate receives $" + formatCurrency(timeSavingsValue) + " through royalties on franchise revenue increases" 
              : "Reduced system refreshing, fewer workarounds, and streamlined patient processing"}
          </p>
        </div>
        
        <div>
          <div className="flex justify-between items-center mb-1">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-[#38003C]/80 mr-2"></div>
              <span className="font-medium">Revenue Leakage Recovery</span>
            </div>
            <span className="font-medium">{formatCurrency(revenueLeakageRecovery)}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-[#38003C]/80 h-2.5 rounded-full" 
              style={{ width: calculatePercentage(revenueLeakageRecovery) }}
            ></div>
          </div>
          <p className="text-sm text-gray-600 mt-1">
            {showCorporateView 
              ? "Corporate receives $" + formatCurrency(revenueLeakageRecovery) + " through royalties on recovered revenue" 
              : "Decreased payment processing errors and reduced revenue leakage"}
          </p>
        </div>
        
        <div>
          <div className="flex justify-between items-center mb-1">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-[#38003C]/60 mr-2"></div>
              <span className="font-medium">Retention Improvement</span>
            </div>
            <span className="font-medium">{formatCurrency(retentionImprovementValue)}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-[#38003C]/60 h-2.5 rounded-full" 
              style={{ width: calculatePercentage(retentionImprovementValue) }}
            ></div>
          </div>
          <p className="text-sm text-gray-600 mt-1">
            {showCorporateView 
              ? "Corporate receives $" + formatCurrency(retentionImprovementValue) + " through royalties on increased retention revenue" 
              : "Improved membership management leading to better wellness plan retention"}
          </p>
        </div>
        
        <div>
          <div className="flex justify-between items-center mb-1">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-[#38003C]/40 mr-2"></div>
              <span className="font-medium">IT Cost Reduction</span>
            </div>
            <span className="font-medium">{formatCurrency(itCostReduction)}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-[#38003C]/40 h-2.5 rounded-full" 
              style={{ width: calculatePercentage(itCostReduction) }}
            ></div>
          </div>
          <p className="text-sm text-gray-600 mt-1">
            {showCorporateView 
              ? "100% of IT cost savings accrue to corporate" 
              : "IT cost reduction, decreased downtime, and improved system resilience"}
          </p>
        </div>
        
        <div className="pt-4 border-t border-gray-200">
          <div className="flex justify-between items-center">
            <span className="font-semibold">Total Annual Benefits</span>
            <span className="font-semibold">{formatCurrency(totalBenefits)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BenefitsBreakdown;

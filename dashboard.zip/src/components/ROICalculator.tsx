import React from 'react';
import { Slider } from "../components/ui/slider";
import { BusinessCaseData } from '../lib/data';
import MethodologyDropdown from './MethodologyDropdown';

interface ROICalculatorProps {
  data: BusinessCaseData;
  onDataChange: (newData: Partial<BusinessCaseData>) => void;
}

const ROICalculator: React.FC<ROICalculatorProps> = ({ data, onDataChange }) => {
  const handleClinicCountChange = (value: number[]) => {
    onDataChange({ clinicCount: value[0] });
  };
  
  const handleAverageVisitsChange = (value: number[]) => {
    onDataChange({ averageVisitsPerDay: value[0] });
  };
  
  const handleRefreshReductionChange = (value: number[]) => {
    onDataChange({ refreshReductionPercent: value[0] });
  };
  
  const handleWorkaroundReductionChange = (value: number[]) => {
    onDataChange({ workaroundReductionPercent: value[0] });
  };
  
  const handleExtraStepsReductionChange = (value: number[]) => {
    onDataChange({ extraStepsReductionPercent: value[0] });
  };
  
  const handleRevenueLeakageRecoveryChange = (value: number[]) => {
    onDataChange({ revenueLeakageRecoveryPercent: value[0] });
  };
  
  const handleRetentionIncreaseChange = (value: number[]) => {
    onDataChange({ retentionIncreasePoints: value[0] });
  };
  
  const handleITCostReductionChange = (value: number[]) => {
    onDataChange({ itCostReductionPercent: value[0] });
  };
  
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
      <h2 className="text-xl font-bold mb-4 text-[#38003C]">ROI Calculator</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-semibold mb-4 text-[#38003C]">Assumptions</h3>
          
          <div className="mb-6">
            <h4 className="font-medium mb-2 text-[#38003C]">Clinic Operations</h4>
            
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <label className="text-sm font-medium">Number of Clinics</label>
                <MethodologyDropdown title="Number of Clinics">
                  <div>
                    <p>The Joint currently operates 950+ clinics across the US. Adjust based on projected growth.</p>
                    <p>Source: The Joint Chiropractic corporate data, Q1 2025.</p>
                  </div>
                </MethodologyDropdown>
              </div>
              <Slider
                defaultValue={[data.clinicCount]}
                max={1200}
                min={500}
                step={10}
                value={[data.clinicCount]}
                onValueChange={handleClinicCountChange}
              />
              <div className="text-right text-sm mt-1">{data.clinicCount}</div>
            </div>
            
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <label className="text-sm font-medium">Average Visits Per Day</label>
                <MethodologyDropdown title="Average Visits Per Day">
                  <div>
                    <p>Survey data indicates an average of 40 patient visits per day across clinics.</p>
                    <p>Source: Survey of 411 staff members, March 2025.</p>
                  </div>
                </MethodologyDropdown>
              </div>
              <Slider
                defaultValue={[data.averageVisitsPerDay]}
                max={60}
                min={20}
                step={1}
                value={[data.averageVisitsPerDay]}
                onValueChange={handleAverageVisitsChange}
              />
              <div className="text-right text-sm mt-1">{data.averageVisitsPerDay}</div>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium mb-2 text-[#38003C]">Time Savings</h4>
            
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <label className="text-sm font-medium">% Reduction in System Refresh Time</label>
                <MethodologyDropdown title="System Refresh Time Reduction">
                  <div>
                    <p>76.3% of staff report spending an average of 60 minutes per day on system refreshes.</p>
                    <p>The slider represents the percentage reduction in this time that will be achieved.</p>
                    <p>Source: Survey of 411 staff members, March 2025.</p>
                  </div>
                </MethodologyDropdown>
              </div>
              <Slider
                defaultValue={[data.refreshReductionPercent]}
                max={100}
                min={0}
                step={5}
                value={[data.refreshReductionPercent]}
                onValueChange={handleRefreshReductionChange}
              />
              <div className="text-right text-sm mt-1">{data.refreshReductionPercent}%</div>
            </div>
            
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <label className="text-sm font-medium">% Reduction in Workarounds</label>
                <MethodologyDropdown title="Workarounds Reduction">
                  <div>
                    <p>68.4% of staff report spending an average of 22.5 minutes per day on workarounds.</p>
                    <p>The slider represents the percentage reduction in this time that will be achieved.</p>
                    <p>Source: Survey of 411 staff members, March 2025.</p>
                  </div>
                </MethodologyDropdown>
              </div>
              <Slider
                defaultValue={[data.workaroundReductionPercent]}
                max={100}
                min={0}
                step={5}
                value={[data.workaroundReductionPercent]}
                onValueChange={handleWorkaroundReductionChange}
              />
              <div className="text-right text-sm mt-1">{data.workaroundReductionPercent}%</div>
            </div>
            
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <label className="text-sm font-medium">% Reduction in Extra Steps</label>
                <MethodologyDropdown title="Extra Steps Reduction">
                  <div>
                    <p>62.8% of staff report spending approximately 1.5 minutes per patient visit on unnecessary steps.</p>
                    <p>The slider represents the percentage reduction in this time that will be achieved.</p>
                    <p>Source: Survey of 411 staff members, March 2025.</p>
                  </div>
                </MethodologyDropdown>
              </div>
              <Slider
                defaultValue={[data.extraStepsReductionPercent]}
                max={100}
                min={0}
                step={5}
                value={[data.extraStepsReductionPercent]}
                onValueChange={handleExtraStepsReductionChange}
              />
              <div className="text-right text-sm mt-1">{data.extraStepsReductionPercent}%</div>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-semibold mb-4 text-[#38003C]">Error Reduction & Revenue</h3>
          
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <label className="text-sm font-medium">% Recovery of Lost Revenue</label>
              <MethodologyDropdown title="Revenue Leakage Recovery">
                <div>
                  <p>53.4% of staff report payment processing failures resulting in an estimated 1.5% revenue leakage.</p>
                  <p>The slider represents the percentage of this lost revenue that will be recovered.</p>
                  <p>Source: Survey of 411 staff members and financial analysis, March 2025.</p>
                </div>
              </MethodologyDropdown>
            </div>
            <Slider
              defaultValue={[data.revenueLeakageRecoveryPercent]}
              max={100}
              min={0}
              step={5}
              value={[data.revenueLeakageRecoveryPercent]}
              onValueChange={handleRevenueLeakageRecoveryChange}
            />
            <div className="text-right text-sm mt-1">{data.revenueLeakageRecoveryPercent}%</div>
          </div>
          
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <label className="text-sm font-medium">Percentage Point Increase in Retention</label>
              <MethodologyDropdown title="Retention Improvement">
                <div>
                  <p>Patient retention has declined from 70% to 64% over the past 18 months.</p>
                  <p>The slider represents the percentage point increase in retention that will be achieved.</p>
                  <p>Each percentage point is estimated ~$10K per clinic in annual revenue.</p>
                  <p>Source: The Joint Chiropractic corporate data, Q1 2025.</p>
                </div>
              </MethodologyDropdown>
            </div>
            <Slider
              defaultValue={[data.retentionIncreasePoints]}
              max={6}
              min={0}
              step={0.5}
              value={[data.retentionIncreasePoints]}
              onValueChange={handleRetentionIncreaseChange}
            />
            <div className="text-right text-sm mt-1">{data.retentionIncreasePoints}%</div>
          </div>
          
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <label className="text-sm font-medium">% Reduction in IT Support Costs</label>
              <MethodologyDropdown title="IT Cost Reduction">
                <div>
                  <p>Current IT support costs for the Front Office system are approximately $1.5M annually.</p>
                  <p>The slider represents the percentage reduction in these costs that will be achieved through the microservices architecture.</p>
                  <p>Source: The Joint Chiropractic IT department, Q1 2025.</p>
                </div>
              </MethodologyDropdown>
            </div>
            <Slider
              defaultValue={[data.itCostReductionPercent]}
              max={50}
              min={0}
              step={5}
              value={[data.itCostReductionPercent]}
              onValueChange={handleITCostReductionChange}
            />
            <div className="text-right text-sm mt-1">{data.itCostReductionPercent}%</div>
          </div>
          
          <div className="mt-8">
            <h4 className="font-medium mb-2 text-[#38003C]">Implementation</h4>
            
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <label className="text-sm font-medium">Implementation Cost</label>
                <MethodologyDropdown title="Implementation Cost">
                  <div>
                    <p>The implementation cost includes:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Development: $225,000</li>
                      <li>Testing: $50,000</li>
                      <li>Training: $25,000</li>
                      <li>Deployment: $25,000</li>
                    </ul>
                    <p>This cost is borne entirely by corporate, while benefits accrue to both corporate and franchisees.</p>
                    <p>Source: The Joint Chiropractic IT department and vendor quotes, Q1 2025.</p>
                  </div>
                </MethodologyDropdown>
              </div>
              <div className="bg-gray-100 p-3 rounded-md text-center font-semibold">
                ${data.implementationCost.toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ROICalculator;

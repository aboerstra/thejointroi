import React from 'react';

const DashboardHeader: React.FC = () => {
  return (
    <div className="bg-[#3A0A3A] text-white rounded-lg shadow-lg p-6 mb-6">
      <div className="flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-4 md:mb-0">
          <div className="mr-4">
            <img 
              src="/images/Faye Logo - White.png" 
              alt="Faye Logo" 
              className="h-12"
            />
          </div>
          <div>
            <p className="text-sm">WE EAT SOFTWARE</p>
          </div>
        </div>
        <div className="text-right">
          <h2 className="text-2xl font-bold">Front Office Business Case</h2>
          <p className="text-sm">The Joint Chiropractic</p>
        </div>
      </div>
      
      <div className="mt-6">
        <p className="text-lg">
          An interactive business case for implementing Front Office system improvements 
          across The Joint Chiropractic's network of clinics.
        </p>
      </div>
    </div>
  );
};

export default DashboardHeader;

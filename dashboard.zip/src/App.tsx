import React, { useState } from 'react';
import Dashboard from './components/Dashboard';
import './index.css';

function App() {
  // Remove red bar and position toggle correctly
  React.useEffect(() => {
    // Function to remove red bar
    const removeRedBar = () => {
      const redBars = document.querySelectorAll('div[style*="background-color: red"], div[style*="background-color:#ff0000"], div[style*="background-color: #ff0000"], div[style*="background-color:red"], div[style*="background:red"], div[style*="background: red"]');
      redBars.forEach(bar => {
        if (bar instanceof HTMLElement) {
          bar.style.display = 'none';
        }
      });
      
      // Also remove any elements with red background
      const allElements = document.querySelectorAll('*');
      allElements.forEach(el => {
        if (el instanceof HTMLElement) {
          const style = window.getComputedStyle(el);
          if (style.backgroundColor === 'rgb(255, 0, 0)' || 
              style.backgroundColor === '#ff0000' || 
              style.backgroundColor === 'red') {
            el.style.display = 'none';
          }
        }
      });
    };
    
    // Function to move toggle below header
    const moveToggle = () => {
      const toggleContainer = document.getElementById('toggle-container');
      if (!toggleContainer) return;
      
      const header = document.querySelector('.bg-purple-900');
      if (header) {
        // Insert toggle after the header
        header.parentNode?.insertBefore(toggleContainer, header.nextSibling);
        toggleContainer.style.display = 'block';
      }
    };
    
    // Run immediately and also after a delay to ensure DOM is fully loaded
    removeRedBar();
    moveToggle();
    
    // Run again after a delay to catch any dynamically added elements
    setTimeout(() => {
      removeRedBar();
      moveToggle();
    }, 500);
    
    // Run periodically to ensure red bar stays removed
    const interval = setInterval(() => {
      removeRedBar();
    }, 2000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <Dashboard />
  );
}

export default App;

🟣 1. Brand Colors
Primary Colors
Name	HEX	RGB	Pantone
Faye Blueberry	#38003C	(56, 0, 60)	2627 C
Faye Green	#16815A	(22, 129, 90)	2244 C
White	#FFFFFF	(255, 255, 255)	—
Grey	#ACACAC	(172, 172, 172)	Cool Grey 4C

Secondary "Techno" Colors
Name	HEX	RGB	Pantone
Tech Violet	#7A39ED	(122, 55, 237)	2665 C
Tech Pink	#FFADDE	(255, 173, 222)	230 C
Tech Teal	#04DFC6	(4, 223, 198)	2239 C
Tech Lime	#B2F000	(178, 240, 0)	3570 C
Tech Blue	#1200F1	(18, 0, 241)	2736 C

Use tints of dark tones or white to balance the energetic palette.

🔤 2. Typography
Headings
Font: F37 Judge Condensed

Style: Bold, geometric sans-serif

Usage: For large impactful headlines

Sub-Headings
Font: Agrandir Wide Light (by Pangram Pangram)

Usage: For quotes or section intros — not body copy

Body Text
Font: Agrandir Regular

Style: Futuristic, clean sans-serif